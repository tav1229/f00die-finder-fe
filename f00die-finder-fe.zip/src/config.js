export const baseUrl = 'https://f00diefinder.id.vn/api'
// export const baseUrl = 'http://localhost:5016/api';
// export const baseUrl = 'http://10.10.29.162:7185/ap i'
// export const baseUrl = 'http://10.10.53.123:7185/api'

